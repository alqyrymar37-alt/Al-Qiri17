# Architecture

AlQiri is an Android application with a local-first design.

## Main components

- `MainActivity`: UI and user interaction.
- `Brain`: command routing and assistant behavior.
- `LocalAiEngine`: local generative AI integration.
- `WebSearch`: web search/opening support.
- `PhoneTools`: optional phone/device actions.
- `UnknownCallDetector`: optional unknown-number call detection.
- `SecureStore`: local secure storage used by features that explicitly persist data.

## Privacy model

The application should not silently persist conversations. User-triggered save is the intended persistence path. Features requiring Android permissions should request them at runtime and degrade gracefully when denied.

## AI model

On supported devices, the application can use Android's on-device generative AI stack without an application API key. Device support and model availability are determined at runtime.
