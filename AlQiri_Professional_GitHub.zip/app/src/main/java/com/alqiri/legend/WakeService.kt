package com.alqiri.legend

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.coroutines.resume

/**
 * Hands-free "يا قيري" mode: keeps listening in the background (foreground service with a visible notification).
 * Say "يا قيري" + a command; sensitive actions (call / SMS / location share) are confirmed by voice.
 * SAFETY: when the phone is locked with a PIN/pattern/fingerprint nothing is executed, because anyone nearby
 * could say the wake word. Android also does not allow any app to unlock the screen.
 */
class WakeService : Service() {

    companion object {
        const val ACTION_STOP = "com.alqiri.legend.WAKE_STOP"
        private const val CHANNEL = "alqiri_wake"
        private const val NOTIF_ID = 42

        /** True while the service is alive (read by the UI). */
        @Volatile var running = false

        /** The screen is open (MainActivity visible): the service pauses so the two microphones don't clash. */
        @Volatile var paused = false

        // Matched against normalized text (hamza/taa marbuta unified), e.g. "يا قيري", "ياقيري", "القيري".
        private val WAKE = Regex("(?:يا\\s*)?(?:ال)?(?:قيري|كيري)")
        private val YES = setOf("نفذ", "ايوه", "ايوا", "اي", "ايه", "تمام", "اكيد", "نعم", "اوكي", "ok", "yes", "ابشر")
        private val NO = setOf("لا", "لاء", "الغاء", "الغي", "بلاش", "وقف", "توقف", "كلا")
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var loopJob: Job? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var toneGen: ToneGenerator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var brain: Brain

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        val tools = PhoneTools(applicationContext, { }, { text -> confirmByVoice(text) })
        brain = Brain(applicationContext, tools)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ar"))
                ttsReady = r != null && r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, buildNotification())
            }
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (loopJob == null) {
            acquireWakeLock()
            loopJob = scope.launch { mainLoop() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        loopJob?.cancel()
        scope.cancel()
        tts?.stop()
        tts?.shutdown()
        try { toneGen?.release() } catch (_: Exception) {}
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        super.onDestroy()
    }

    // ---------------------------------------------------------------- listening loop
    private suspend fun mainLoop() {
        while (true) {
            currentCoroutineContext().ensureActive()
            if (paused) { delay(600); continue }

            val (text, err) = listenOnce()
            if (text == null) {
                if (err == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopSelf(); return }
                val busy = err == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || err == SpeechRecognizer.ERROR_CLIENT
                delay(if (busy) 1500L else 300L)
                continue
            }

            val m = WAKE.find(normArabic(text)) ?: continue
            beep()
            var cmd = text.substring(minOf(m.range.last + 1, text.length)).trim()
            if (cmd.length < 2) {
                // only the wake word was said: listen for the command now
                cmd = listenOnce().first?.trim().orEmpty()
                if (cmd.length < 2) continue
            }
            handleCommand(cmd)
        }
    }

    private suspend fun handleCommand(cmd: String) {
        val km = getSystemService(KeyguardManager::class.java)
        if (km != null && km.isDeviceLocked) {
            speakAndWait("الجوال مقفول يا زعيم. افتحه بنفسك وبعدين ناديني")
            return
        }
        val reply = try {
            withContext(Dispatchers.Default) { brain.handle(cmd) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            "صار خطأ يا زعيم، عيد الامر"
        }
        speakAndWait(reply)
    }

    /** Voice approval for outgoing actions: reads the action aloud, then waits for "نفذ" or "الغاء". */
    private suspend fun confirmByVoice(text: String): Boolean = withContext(Dispatchers.Main) {
        speakAndWait("$text. قل نفذ او الغاء")
        beep()
        val heard = normArabic(listenOnce().first.orEmpty())
        val words = heard.split(Regex("\\s+")).filter { it.isNotBlank() }
        when {
            words.any { it in NO } -> false
            words.any { it in YES } -> true
            else -> false
        }
    }

    // ---------------------------------------------------------------- speech in / out
    private suspend fun listenOnce(): Pair<String?, Int> = suspendCancellableCoroutine { cont ->
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        var finished = false
        fun finish(text: String?, err: Int) {
            if (finished) return
            finished = true
            try { r.destroy() } catch (_: Exception) {}
            if (cont.isActive) cont.resume(Pair(text, err))
        }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { finish(null, error) }
            override fun onResults(results: Bundle?) {
                finish(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull(), 0)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        cont.invokeOnCancellation { finish(null, SpeechRecognizer.ERROR_CLIENT) }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-YE")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try { r.startListening(i) } catch (e: Exception) { finish(null, SpeechRecognizer.ERROR_CLIENT) }
    }

    private suspend fun speakAndWait(text: String) {
        if (!ttsReady) return
        val clean = text
            .replace(Regex("https?://\\S+"), " رابط ")
            .replace(Regex("[^\\p{L}\\p{N}\\p{P}\\p{M}\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(350)
        if (clean.isEmpty()) return
        suspendCancellableCoroutine<Unit> { cont ->
            val id = "q" + System.nanoTime()
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { if (utteranceId == id && cont.isActive) cont.resume(Unit) }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { if (utteranceId == id && cont.isActive) cont.resume(Unit) }
                override fun onError(utteranceId: String?, errorCode: Int) { if (utteranceId == id && cont.isActive) cont.resume(Unit) }
            })
            cont.invokeOnCancellation { tts?.stop() }
            tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, id)
        }
    }

    private fun beep() {
        try {
            val t = toneGen ?: ToneGenerator(AudioManager.STREAM_MUSIC, 90).also { toneGen = it }
            t.startTone(ToneGenerator.TONE_PROP_ACK, 180)
        } catch (_: Exception) {}
    }

    // ---------------------------------------------------------------- plumbing
    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(PowerManager::class.java)
            wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "alqiri:wake")?.apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) {}
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "وضع يا قيري", NotificationManager.IMPORTANCE_LOW))
    }

    private fun buildNotification(): Notification {
        val stop = PendingIntent.getService(
            this, 7, Intent(this, WakeService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 8, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_qiri_mono)
            .setContentTitle("القيري يسمعك 🎙️")
            .setContentText("قل: يا قيري …   |   اضغط ايقاف لإطفاء الاستماع")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "ايقاف", stop)
            .build()
    }
}
